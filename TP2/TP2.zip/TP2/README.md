ATENÇÃO
PARA FAZER ESTE TP EU RENOMEEI OS CSVs recebidos
Iris aleatório virou iris.csv
Iris treino virou treino.csv
Iris teste virou teste.csv
Fiz isso pq o python não lida bem com arquivos com espaços. Inclui os arquivos renomeados no zip de entrega

Para compilar os arquivos bastar escrever

python Kmeans.py

ou 

python KNN.py